﻿namespace LibHac.Bcat;

public enum BcatServiceType
{
    BcatU,
    BcatS,
    BcatM,
    BcatA
}