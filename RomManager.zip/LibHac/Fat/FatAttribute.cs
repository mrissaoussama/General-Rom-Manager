﻿namespace LibHac.Fat;

public struct FatAttribute
{
    public bool IsFatSafeEnabled;
    public bool IsFatFormatNormalized;
    public bool IsTimeStampUpdated;
}