﻿using System;

namespace LibHac.FsSystem;

public delegate void RandomDataGenerator(Span<byte> buffer);