﻿using LibHac.Common.FixedArrays;

namespace LibHac.FsSystem;

public struct Hash
{
    public Array32<byte> Value;
}