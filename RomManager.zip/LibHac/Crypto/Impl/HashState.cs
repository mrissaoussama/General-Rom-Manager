﻿namespace LibHac.Crypto.Impl;

public enum HashState
{
    Initial = 0,
    Initialized,
    Done
}