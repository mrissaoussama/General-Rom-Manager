﻿namespace LibHac.FsSrv.Storage;

public enum StorageDevicePortId : byte
{
    Invalid = 0,
    Mmc = 1,
    SdCard = 2,
    GameCard = 3
}