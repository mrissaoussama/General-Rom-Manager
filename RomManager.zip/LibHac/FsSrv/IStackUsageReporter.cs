﻿namespace LibHac.FsSrv;

public interface IStackUsageReporter
{
    uint GetStackUsage();
}