﻿namespace LibHac.Common;

public enum Validity : byte
{
    Unchecked,
    Invalid,
    Valid,
    MissingKey
}