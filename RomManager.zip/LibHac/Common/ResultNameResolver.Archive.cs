﻿using System;

namespace LibHac.Common;

internal partial class ResultNameResolver
{
    private static ReadOnlySpan<byte> ArchiveData => Array.Empty<byte>();
}