﻿namespace LibHac.Common.Keys;

public enum KeyType
{
    None,
    Common,
    Unique,
    Title
}