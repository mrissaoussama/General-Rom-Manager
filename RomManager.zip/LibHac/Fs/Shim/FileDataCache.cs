﻿// ReSharper disable UnusedMember.Local
using System;
using LibHac.Common;
using LibHac.Diag;
using LibHac.Fs.Impl;
using LibHac.Os;

namespace LibHac.Fs.Impl
{
    /// <summary>
    /// Handles getting scoped read access to the global file data cache.
    /// </summary>
    /// <remarks>Based on nnSdk 14.3.0</remarks>
    internal struct GlobalFileDataCacheAccessorReadableScopedPointer : IDisposable
    {
        private FileDataCacheAccessor _accessor;
        private ReaderWriterLock _lock;

        public GlobalFileDataCacheAccessorReadableScopedPointer()
        {
            _accessor = null;
            _lock = null;
        }

        public void Dispose()
        {
            _lock?.ReleaseReadLock();
        }

        public readonly FileDataCacheAccessor Get() => _accessor;

        public void Set(FileDataCacheAccessor accessor, ReaderWriterLock rwLock)
        {
            if (_lock is not null && _lock != rwLock)
                _lock.ReleaseReadLock();

            _accessor = accessor;
            _lock = rwLock;
        }
    }
}

namespace LibHac.Fs.Shim
{
    /// <summary>
    /// Contains functions for configuring the global file data cache.
    /// </summary>
    /// <remarks>Based on nnSdk 14.3.0</remarks>
    public static class FileDataCacheShim
    {
        internal struct Globals : IDisposable
        {
            public nint FileSystemProxyServiceObjectInitGuard;
            public GlobalFileDataCacheAccessorHolder GlobalFileDataCacheAccessorHolder;

            public void Dispose()
            {
                GlobalFileDataCacheAccessorHolder.Dispose();
            }
        }

        internal class GlobalFileDataCacheAccessorHolder
        {
            private FileDataCacheAccessor _accessor;
            private readonly ReaderWriterLock _accessorLock;
            private long _cacheSize;
            private bool _isDefault;

            public GlobalFileDataCacheAccessorHolder(HorizonClient hos)
            {
                _accessorLock = new ReaderWriterLock(hos.Os);
            }

            public void Dispose()
            {
                _accessorLock?.Dispose();
            }

            public ReaderWriterLock GetLock() => _accessorLock;

            public bool HasAccessor()
            {
                Assert.SdkAssert(_accessorLock.IsReadLockHeld() || _accessorLock.IsWriteLockHeldByCurrentThread());

                return _accessor is not null;
            }

            public void SetAccessor()
            {
                Assert.SdkAssert(_accessorLock.IsWriteLockHeldByCurrentThread());

                _accessor = null;
            }

            public void SetAccessor(FileDataCacheAccessor accessor, long cacheSize, bool isDefault)
            {
                Assert.SdkAssert(_accessorLock.IsWriteLockHeldByCurrentThread());

                _accessor = accessor;
                _cacheSize = cacheSize;
                _isDefault = isDefault;
            }

            public FileDataCacheAccessor GetAccessor()
            {
                Assert.SdkAssert(_accessorLock.IsReadLockHeld() || _accessorLock.IsWriteLockHeldByCurrentThread());

                return _accessor;
            }

            public long GetCacheSize()
            {
                Assert.SdkAssert(_accessorLock.IsReadLockHeld() || _accessorLock.IsWriteLockHeldByCurrentThread());

                return _cacheSize;
            }

            public bool IsDefaultGlobalFileDataCache()
            {
                Assert.SdkAssert(_accessorLock.IsReadLockHeld() || _accessorLock.IsWriteLockHeldByCurrentThread());
                Assert.SdkNotNull(_accessor);

                return _isDefault;
            }
        }

        internal static bool IsGlobalFileDataCacheEnabled(this FileSystemClientImpl fs)
        {
            return false;
        }

        internal static bool TryGetGlobalFileDataCacheAccessor(this FileSystemClientImpl fs,
            ref GlobalFileDataCacheAccessorReadableScopedPointer scopedPointer)
        {
            throw new NotImplementedException();
        }

        internal static void SetGlobalFileDataCacheAccessorForDebug(this FileSystemClientImpl fs,
            FileDataCacheAccessor accessor)
        {
            throw new NotImplementedException();
        }

        public static void EnableGlobalFileDataCache(this FileSystemClient fs, Memory<byte> buffer)
        {
            throw new NotImplementedException();
        }

        public static void DisableGlobalFileDataCache(this FileSystemClient fs)
        {
            throw new NotImplementedException();
        }

        public static void EnableDefaultGlobalFileDataCache(this FileSystemClient fs, Memory<byte> buffer)
        {
            throw new NotImplementedException();
        }

        public static bool IsDefaultGlobalFileDataCacheEnabled(this FileSystemClient fs)
        {
            throw new NotImplementedException();
        }
    }
}