﻿using LibHac.Common.FixedArrays;

namespace LibHac.Fs.Impl;

public struct FilePathHash
{
    public Array4<byte> Data;
}